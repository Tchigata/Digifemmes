package main

import (
	"database/sql"
	"fmt"
	"log"
	"net/http"
	"text/template"

	_ "github.com/go-sql-driver/mysql"
)

type Employee struct {
	Id   int
	Name string
	City string
}

type Utilisateur struct {
	Id      int
	Nom     string
	Email   string
	Ville   string
	Sujet   string
	Message string
}

type AfficheBlog struct {
	IdBlog          int
	Categorie       string
	ContenuImage    string
	ContenuText     string
	DatePublication string
}

func dbConn() (db *sql.DB) {

	db, err := sql.Open("mysql", "root:@tcp(localhost:3306)/batiks")
	if err != nil {
		panic(err.Error())
	}
	return db
}

func Index(w http.ResponseWriter, r *http.Request) {
	db := dbConn()
	var tmpl = template.Must(template.ParseFiles("index.html"))
	tmpl.ExecuteTemplate(w, "index.html", nil)
	defer db.Close()
}

func About(w http.ResponseWriter, r *http.Request) {
	db := dbConn()
	var tmpl = template.Must(template.ParseFiles("about.html"))
	tmpl.ExecuteTemplate(w, "about.html", nil)
	defer db.Close()
}

func Porfolio(w http.ResponseWriter, r *http.Request) {
	db := dbConn()
	var tmpl = template.Must(template.ParseFiles("portfolio.html"))
	tmpl.ExecuteTemplate(w, "portfolio.html", nil)
	defer db.Close()
}

func Blog(w http.ResponseWriter, r *http.Request) {
	db := dbConn()
	var tmpl = template.Must(template.ParseFiles("blog.html"))
	tmpl.ExecuteTemplate(w, "blog.html", nil)
	defer db.Close()
}

func Contact(w http.ResponseWriter, r *http.Request) {
	db := dbConn()
	var tmpl = template.Must(template.ParseFiles("contact.html"))
	tmpl.ExecuteTemplate(w, "contact.html", nil)
	defer db.Close()
}

func Insert(w http.ResponseWriter, r *http.Request) {
	db := dbConn()
	if r.Method == "POST" {
		nom := r.FormValue("nom")
		email := r.FormValue("email")
		sujet := r.FormValue("sujet")
		message := r.FormValue("message")

		insForm, err := db.Exec("INSERT INTO utilisateur (nom, email, sujet, message) VALUES(?,?,?,?)",
			nom, email, sujet, message)
		if err != nil {
			panic(err.Error())
		}

		fmt.Println(insForm, err)
		// insForm.Exec(nom, email, sujet, message)
		log.Println("INSERT: Name: " + nom + " | email: " + email)
	}
	defer db.Close()
	http.Redirect(w, r, "/", 301)
}

func Afficher(w http.ResponseWriter, r *http.Request) {
	fmt.Println("ok")
	db := dbConn()
	// nId := r.URL.Query().Get("id")
	selDB, err := db.Query("SELECT id_blog, categorie, contenu_image, contenu_text, date_publication FROM blog ORDER BY id ASC")
	if err != nil {
		panic(err.Error())
	}

	fmt.Println(selDB)
	emp := AfficheBlog{}
	res := []AfficheBlog{}
	for selDB.Next() {
		var id_blog int
		var categorie, contenu_image, contenu_text, date_publication string

		err = selDB.Scan(&id_blog, &contenu_image, &contenu_text, &date_publication)
		if err != nil {
			panic(err.Error())
		}
		emp.IdBlog = id_blog
		emp.Categorie = categorie
		emp.ContenuImage = contenu_image
		emp.ContenuText = contenu_text
		emp.DatePublication = date_publication
		res = append(res, emp)
	}

	fmt.Println("ok")
	var tmpl = template.Must(template.ParseFiles("contact.html"))
	tmpl.ExecuteTemplate(w, "contact.html", res)
	defer db.Close()
}

func main() {
	log.Println("Server started on: http://localhost:3000")

	http.Handle("/css/", http.StripPrefix("/css/", http.FileServer(http.Dir("./css/"))))
	http.Handle("/img/", http.StripPrefix("/img/", http.FileServer(http.Dir("./img/"))))
	http.Handle("/lib/", http.StripPrefix("/lib/", http.FileServer(http.Dir("./lib/"))))
	http.Handle("/js/", http.StripPrefix("/js/", http.FileServer(http.Dir("./js/"))))
	http.Handle("/scss/", http.StripPrefix("/scss/", http.FileServer(http.Dir("./scss/"))))

	http.HandleFunc("/", Index)
	http.HandleFunc("/about", About)
	http.HandleFunc("/porfolio", Porfolio)
	http.HandleFunc("/blog", Blog)
	http.HandleFunc("/contact", Contact)
	http.HandleFunc("/insert", Insert)
	http.HandleFunc("/afficher", Afficher)
	http.ListenAndServe(":3000", nil)
}
